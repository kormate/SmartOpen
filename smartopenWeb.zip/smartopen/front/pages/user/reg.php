<?php
	$message=reg();
?>

<div class="page">
<h2>Regisztráció</h2>
<?php echo $message ?>
<form method="POST" action="" onsubmit="return equal();">
<div>
	<label>Név:</label>
	<input type="text" name="name" required>
</div>
<div>
	<label>Email:</label>
	<input type="email" name="email" required>
</div>
<div>
	<label>Jelszó:</label>
	<input type="password" name="pw" id="pw" required onkeyup='equal();'>
	<img src ='./front/img/eye1.png' id='eye' onclick='pw_see();'>
</div>
<div>
	<label>Jelszó mégegyszer:</label>
	<input type="password" name="pw2" id="pw2" required onkeyup='equal();'>
	<img src ='./front/img/nonequal.png' id='pipa'>
</div>
	<input type="submit" name="send" value="Regisztrálok">
    <div>
Már regisztráltál?<a href='./?p=login'> >>> Belépés</a>
</div>
</form>

</div>