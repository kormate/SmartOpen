<?php 
// api

		//saját api közvetlen használata
		include_once("api/db_connect.php");
		include_once("api/crud.php");

// back

		//belépés és egyéb munkamenet vizsgálata
		include_once("back/session.php");
		
		// saját függvények
		include_once("back/functions.php");
		
		// felhasználói és regisztrációs oldal kezelése
		include_once("back/user/new-user.php");
		include_once("back/user/login-user.php");
		
		$login=isset($_SESSION["name"]);
		if ($login) $name=$_SESSION["name"];

// front

		// alap beállítások
		$myUrl=		"http://localhost/smartopen/";
		$apiUrl=	"http://localhost/smartopen/api/";


		// saját függvények
		include_once("front/functions.php");
		
		// oldal betöltés
		include_once("front/load.php");

?>