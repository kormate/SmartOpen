const scanner = new Html5QrcodeScanner('reader', { 
    qrbox: {
        width: 250,
        height: 250,
    },
    fps: 20,
});

function startScanner() {
    document.getElementById('userbutton-qr').remove();
    scanner.render(success, error);
    
}

function success(result) {
    // Eltároljuk az eredményt a helyi tárolóban
    localStorage.setItem('qrResult', result);
    // Sikeres beolvasás után megjelenítjük az eredményt
    document.getElementById('result').innerHTML = `<h2>Beolvasás sikeres!</h2><p><a href="${result}">${result}</a></p>`;
    // Elküldjük az eredményt a szervernek
    elkuld(result);
    // Leállítjuk a scanner-t és eltávolítjuk az olvasó elemet
    scanner.clear();

   
}

function error(err) {
    console.error(err);
}

function elkuld(adatom) {
    // AJAX kérés indítása a PHP fájlhoz
    fetch('./front/pages/admin/qrolvasas.php', {
        method: 'POST', // POST kérés
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded', // Adattípus megadása
        },
        body: `ertek=${encodeURIComponent(adatom)}` // Az adat URL-kódolt formában
    })
    .then(response => response.text()) // A válasz szöveggé alakítása
    .then(data => {
        // A válasz tartalmának megjelenítése a képernyőn
        document.getElementById('result').innerHTML = data;
    })
    .catch(error => {
        console.error('Hiba az AJAX kérésnél:', error);
    });
}

// Kattintás kezelése a QR olvasó indításához
document.getElementById('userbutton-qr').addEventListener('click', startScanner);
