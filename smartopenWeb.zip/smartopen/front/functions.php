<?php 
function getApi($url) {
    $json=file_get_contents($url);
    switch (http_response_code()) {
        case 200: { return json_decode($json,true); break;}
        case 204: { return array(); break;}
        case 404: { return false;}
    }
}

//"UPDATE felhasznalok SET fstatusz = '$userstatus' WHERE fmail = '$userid'"; modify  ac CRUD-ban
function ujra($sql) {
    modify($sql);
}

function idopont() {
    $currentDate = new DateTime();
    $formattedDate = $currentDate->format('Y-m-d H:i:s');
    return $formattedDate;
}

function aktualisDatum() {  
    $currentDate = new DateTime();
    $formattedDate = $currentDate->format('Y-m-d');
    return $formattedDate;
}


function keresekNapot($userid, $nap) {
    readItem("nap", "$userid", $nap);
}
function belephet ($kapukod, $ertek) {
    if ($kapukod == $ertek) {
        return true;
    }
    else {
        return false;
    }
}

function mindenNap() {
    global $apiUrl;
    return getApi("http://localhost/smartopen/api/"."?nap=mind");
}