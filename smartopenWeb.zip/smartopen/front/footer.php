<footer class="w3-container w3-padding-64 w3-center w3-black w3-xlarge lab">
 <p class="w3-medium">SmartOpen Beléptetőrendszer</p>
</footer>
</body>
</html>