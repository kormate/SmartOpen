<?php
function login() {
    $message="";
    if (isset($_POST["send"])) {
        $record=readItem("felhasznalok","fmail","'$_POST[email]'");
        if ($record!==false){
            if (count($record)==0) {
                $message= "$_POST[email] email címmel még nem regisztráltak";
            }
            else {
                $salt=$record[0]["fsalt"];
                $pw_crypt_post=crypt($_POST["pw"],"$6$".$salt."$");
                $pw_crypt="$6$".$salt."$".$record[0]["fpw"];
                if ($pw_crypt_post==$pw_crypt) {
                    $message= "OK";
                    $kapukod=readAll("qrkod");
                    new_session("mail",$_POST["email"]);
                    new_session("name",$record[0]["fname"]);
                    new_session("status",$record[0]["fstatusz"]);
                    new_session("kapukod",$kapukod[0]["qrszam"]);

                }
                else {
                    $message= "Nem megfelelő jelszó";
                }
            }
        }
        else {
            $message= "Sikertelen belépés, próbálja később!";
        }
    }
    return $message;
}



