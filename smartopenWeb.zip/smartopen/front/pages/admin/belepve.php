<?php
include_once ("G:/Saját meghajtó/kodolas/htdocs/smartopen/front/functions.php");

// Session indítása, ha még nincs elindítva
if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

$usernev = $_SESSION["name"] ?? '';
$userid = $_SESSION["mail"] ?? '';
$userstatus = $_SESSION["status"] ?? '';
$kapukod = $_SESSION["kapukod"] ?? '';



// JavaScript kód a PHP változók értékeinek beállítására
echo "<script>
    document.getElementById('usernev').innerText = '$usernev';
    document.getElementById('userid').innerText = '$userid';
    document.getElementById('userstatus').innerText = '$userstatus';
    document.getElementById('kapukod').innerText = '$kapukod';

</script>";
?>



<form action="?p=qr" method="post">
    <button name="userbutton-qr" class="w3-button w3-block w3-purple w3-round-large w3-xlarge">QR kód olvasása</button><br>
</form>

<form action="?p=betegseg" method="post">
    <button name="userbutton-betegseg" class="w3-button w3-block w3-red w3-round-large w3-xlarge">Betegség</button><br>
</form>

<form action="?p=szabadsag" method="post">
    <button name="userbutton-szabadsag" class="w3-button w3-block w3-orange w3-round-large w3-xlarge">Szabadság</button><br>
</form>
