<?php

include_once ("G:/Saját meghajtó/kodolas/htdocs/smartopen/front/functions.php");

if (session_status() == PHP_SESSION_NONE) {
    session_start();  // Ha nincs, indítsunk egyet
}

$_SESSION["status"] = "Szabadsag";

$usernev = $_SESSION["name"] ?? '';
$userid = $_SESSION["mail"] ?? '';
$userstatus = $_SESSION["status"] ?? '';
$kapukod = $_SESSION["kapukod"] ?? '';

echo "<script>
    document.getElementById('usernev').innerText = '$usernev';
    document.getElementById('userid').innerText = '$userid';
    document.getElementById('userstatus').innerText = '$userstatus';
    document.getElementById('kapukod').innerText = '$kapukod';

</script>";

$sql="UPDATE felhasznalok SET fstatusz = '$userstatus' WHERE fmail = '$userid'";
ujra($sql);


?>