<?php
$page="pages/start.php";
$cim="Mi az a Smart Open?";

if (isset($_GET['p'])){
	switch ($_GET['p']) {
		
		case '1': 				{				$page="pages/user/login.php"; 		$cim="Belépés admin@gmail.com/12345678"; break; }
		case 'admin': 			{  				$page="front/pages/admin/belepve.php"; 			$cim="Be vagy lépve!"; break; }
		case 'qr':				{if ($login)	$page="front\pages\admin\qrolvasas.php"; 		$cim="Olvassa be a QR kódot!"; break; }
		case 'betegseg':		{if ($login)	$page="front\pages\admin\betegseg.php"; 		$cim="A mai napra betegszabadság"; break; }
		case 'szabadsag':		{if ($login)	$page="front\pages\admin\szabadsag.php"; 		$cim="A mai napra szabadnap"; break; }
		case 'aktiv':			{if ($login)	$page="front\pages\admin\aktiv.php"; 			$cim="Beolvastad a QR kodot"; break; }

	}
}

?>
