<div id="reader" style="width: 300px; height: 300px;"></div>
<div id="result"></div>

<script>

    const scanner = new Html5QrcodeScanner('reader', { 
        // ide jön az olvaso
        qrbox: {
            width: 250,
            height: 250,
        },  
        fps: 20, 
    });

    scanner.render(success, error);
    // Starts scanner

    function success(result) {

        document.getElementById('result').innerHTML = `
        <h2>Success!</h2>
        <p><a href="${result}">${result}</a></p>
        `;
        
        scanner.clear();

        document.getElementById('reader').remove();
    
    }

    function error(err) {
        console.error(err);
        
    }

</script>