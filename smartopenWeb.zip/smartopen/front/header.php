<!DOCTYPE html>
<html>
<title>SmartOpen</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<script src="https://unpkg.com/html5-qrcode" type="text/javascript"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">


<script src="https://kit.fontawesome.com/yourcode.js" crossorigin="anonymous"></script>
<script src="https://unpkg.com/html5-qrcode" type="text/javascript"></script>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<link rel="stylesheet" href=".\front\css\styles.css"/>

<body>

<div class="w3-container w3-center head">

  <h1 class="kiseroszin">SmartOpen</h1>
  <h3 class="vilagos">BELÉPTETŐRENDSZER</h3>
  <h6 id="usernev" class="vilagos">Felhasznalo neve</h6>
  <h6 id="userid" class="vilagos">Felhasznalo email (kulcs)k</h6>
  <h6 id="userstatus" class="vilagos">Felhasznaló statusza</h6>
  <h6 id="kapukod" class="vilagos">kapukod adatbazisbol</h6>
  <h6 id="beolvasottqr" class="vilagos">beolvasott qr kod</h6>

</div>

<header>

  <div class="w3-bar w3-border w3-light-grey w3-center menusav">

    <a href='./?p=0' style="width:50%" class="w3-bar-item w3-button w3-mobile kiemelt">Kezdőoldal</a>
    <a href='./?p=1' style="width:50%" class="w3-bar-item w3-button w3-mobile kiemelt">Munkatárs</a>

  </div>

</header>

