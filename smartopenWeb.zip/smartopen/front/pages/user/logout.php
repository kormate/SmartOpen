<h2>Kilépés</h2>
<?php
if ($_GET["id"]) {
    if (logout($_GET["id"])) {
        echo "<p>Sikeres kijelentkezés</p>";
        header("Refresh:2,url=./?p=login");
    }
}

?>