
<?php
    $message=login();
    if ($message== "OK") header("Location:./?p=admin");
?>
<div class="w3-panel text-box">

    <div class="w3-container">
        
</div>

<form method="POST" action="" onsubmit="return equal()" class="w3-container formbox">
<br><br>
  <div>
    <label>Email címe:</label>
    <div class="inputmezo">
      <input class="w3-input" type="email" name="email" required>
      <img class="form-ikon" src="./front/img/account.png">
    </div>
  </div><br>

  <div>
    <label>Jelszava:</label>
    <div class="inputmezo">
    <input class="w3-input" type="password" name="pw" id="pw" required>
    <img class="eye" src="./front/img/eye1.png" id="eye" onclick="pw_see();">
    </div>
  </div><br><br>

  <input class="w3button w3-purple" type="submit" name="send" value="Belépés"><br><br>


</form>

