<main class="w3-container w3-center main">

    <div class="w3-center main-box">
        <br><br>
        <h3><?php echo $cim ?></h3>
        <?php include_once($page); ?>
    </div>

</main>
<script src='./front/js/scripts.js'></script>
<script src='./front/js/szkenneles.js'></script>