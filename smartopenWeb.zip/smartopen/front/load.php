<?php
// menükezelés
	include_once("menu.php");
// fejrész
	include_once("header.php");
// main
	include_once("main.php");
// lábrész
	include_once("footer.php");

?>