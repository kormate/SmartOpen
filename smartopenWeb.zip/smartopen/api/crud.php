<?php

function query($sql) {
	$array=false;
	$result=connect()->query($sql);
	if ($result) {
        $array=[];
        while ($row=$result->fetch_assoc())
            $array[]=$row;
	}
	connect()->close();
	return $array;
}


function modify($sql) {
	$result=connect()->query($sql);
	connect()->close();
	return $result;
}

function insertRecord($table, $fields, $values) {
    $sql="INSERT INTO $table ($fields) VALUES ($values);";
    return modify($sql);
}

function readItem($table, $field, $value) {
    $sql= "SELECT * FROM $table WHERE $field=$value";
    return query($sql);
}

function readItem2($table, $where) {
    $sql= "SELECT * FROM $table WHERE $where";
    return query($sql);
}

function readAll($table) {
    $sql= "SELECT * FROM $table";
    return query($sql);
} 


function updateRecord($table, $updates, $id_field, $id_value) {
    $sql= "UPDATE $table SET $updates WHERE $id_field=$id_value";
    return modify($sql);
}


function deleteRecord($table, $id_field, $id_value) {
    $sql= "DELETE FROM $table WHERE $id_field=$id_value";
    return modify($sql);
}
?>