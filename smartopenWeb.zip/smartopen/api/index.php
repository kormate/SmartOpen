<?php
include_once("db_connect.php");
include_once("crud.php");


// Lekérdezem a HTTP metódust
$method = $_SERVER['REQUEST_METHOD'];

$ok=false;

// lekérdezések
switch ($method) {

    case "GET": 
        // READ
        $data=$_GET;
        // USER ÁG
        if (isset($data["user"])) {

            if($data["user"]=="mind") {
                $ok =   readAll("felhasznalok");
            }

            else if($data["user"]!="") {
                $ok =   readItem("felhasznalok", "fid", "'$data[user]'");
            }
        }

        // NAP ÁG
        else if (isset($data["nap"]))

            if($data["nap"]=="mind") {
                $ok =   readAll("nap");
            }

            else if (isset($data["nap"]) && $data["nap"] != "") {
                $ok = readItem("nap", "napid", "'$data[nap]'");
            }
        
        if ($ok) {
            $kod= 200;
            $json=$ok;
        }
        else {
            $kod= 404;
            $json=array(
                "minta1" => "?user=mind",
                "minta2" => "?user=1 (ID)",
                "minta3" => "?nap=mind",
                "minta4" => "?nap=20241222",
            );
        }
        break; 

    case "POST":
        // CREATE
        $data = json_decode(file_get_contents("php://input"), true);
        $field="szerzo, cim, ar, megjelenes";
        $values="'$data[szerzo]','$data[cim]', $data[ar], '$data[megjelenes]'";
        $ok = insertRecord("lemez", $field, $values);
        if ($ok) {
            $kod=201;
            $json=['uzenet' => 'Sikeres hozzáadás'];
        }
        else {
            $kod=400;
            $json=['hiba' => 'A hozzáadás sikertelen'];
        }
        break;

    case "PUT": 
        // UPDATE
        $data = json_decode(file_get_contents("php://input"), true);
        $updates="szerzo='$data[szerzo]', cim='$data[cim]', ar=$data[ar], megjelenes='$data[megjelenes]'";
        $ok = updateRecord("lemez",$updates,"id",$data['id']);
        if ($ok) {
            $kod= 204; // 200-as kódnál visszamegy az üzenet
            $json=['üzenet'=> 'Sikeres módosítás']; // ez nem fog átmenni
        }
        else {
            $kod= 400;
            $json=['hiba'=> 'A módosítás sikertelen'];
        }
        break;

    case "DELETE": 
        // DELETE
        $data = json_decode(file_get_contents("php://input"), true);
        $ok = deleteRecord("lemez","id", $data["id"]);
        if ($ok) {
            $kod= 204;
            $json=["üzenet"=> "Sikeres törlés"]; // ez nem fog átmenni
        }
        else {
            $kod= 400;
            $json=["hiba"=> "A törlés sikertelen"];
        }
        break;

    default: 
        $kod= 400;
        $json = ['hiba' => 'Érvénytelen metódus'];
        break;
}

// válasz küldése json formátumban
http_response_code($kod);
header('Content-Type: application/json; charset=utf-8');
print(json_encode($json));

?>