<?php
// munkamenet elindítás
session_start();
$_SESSION['id']=session_id();

function new_session($s_name,$s_value){
    $_SESSION[$s_name] = $s_value;
}

function logout($id){
    $logout=false;
    if ($id==$_SESSION['id']) 
    { 

        session_unset(); // kuka
        session_destroy(); // delete
        $logout=true;
    }
    return $logout;
}
?>