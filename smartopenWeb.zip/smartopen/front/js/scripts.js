function pw_see() {
	if (document.getElementById('pw').type=='password') {
	  document.getElementById('eye').src = './front/img/eye0.png'
	  document.getElementById('pw').type = 'text'
	  document.getElementById('pw2').type = 'text'
	}
	else {
	  document.getElementById('eye').src  = './front/img/eye1.png'
	  document.getElementById('pw').type = 'password'
	  document.getElementById('pw2').type = 'password'
	}
}

function equal() {
	if( document.getElementById('pw').value=='' 	|| 
			document.getElementById('pw2').value=='' 	||
			document.getElementById('pw').value!=document.getElementById('pw2').value 
		) 
	{
	    document.getElementById('pipa').src  = './front/img/nonequal.png'
			eq=false
	}
	else {
	    document.getElementById('pipa').src  = './front/img/pipa.png'
			eq=true
	}
	return eq
}
