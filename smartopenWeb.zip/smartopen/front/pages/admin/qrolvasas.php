<?php

include_once ("G:/Saját meghajtó/kodolas/htdocs/smartopen/front/functions.php");


if (session_status() == PHP_SESSION_NONE) {
    session_start();  // Ha nincs session, indítsunk egyet
}

$usernev = $_SESSION["name"] ?? '';
$userid = $_SESSION["mail"] ?? '';
$userstatus = $_SESSION["status"] ?? '';
$kapukod = $_SESSION["kapukod"] ?? '';

?>

<script>
    document.getElementById('usernev').innerText = '<?php echo $usernev; ?>';
    document.getElementById('userid').innerText = '<?php echo $userid; ?>';
    document.getElementById('userstatus').innerText = '<?php echo $userstatus; ?>';
    document.getElementById('kapukod').innerText = '<?php echo $kapukod; ?>';
    document.getElementById('beolvasottqr').innerText = '<?php echo $kapukod; ?>';
</script>

<div id="reader"></div>
<div id="result"></div>

<button name="userbutton-qr" id="userbutton-qr" class="w3-button w3-block w3-purple w3-round-large w3-xlarge" type="button">Olvasás</button>

<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['ertek'])) {
    $ertek = $_POST['ertek'];

    if ($kapukod == $ertek) {
        ?>
        <form action="?p=aktiv" method="post">
            <button name="userbutton-aktiv" class="w3-button w3-block w3-red w3-round-large w3-xlarge">Elkezdem a munkát</button><br>
        </form>
        <?php
        }
        
    else {
            ?>
            <form action="?p=1" method="post">
            <br>
                <button name="userbutton-inaktiv" class="w3-button w3-block w3-red w3-round-large w3-xlarge">Kilépek</button><br>
            </form>
            <?php
    }
}






?>
