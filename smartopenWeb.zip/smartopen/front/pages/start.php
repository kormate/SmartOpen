
<br><h4>Kérjük, olvassa el figyelmesen a következő ismertetőt!</h4><br>

<p>A SmartOpen egy QR-kód mobiltelefonon történő beolvasása segítségével naplózza a be és kilépéseket. Jelezheti felettesének ha Homeoffice-ban dolgozik, vagy ha szabadságon, betegszabadságon van</p>

<p>A menüben található <span class="kiemelt">Kezdőoldal</span> gombra kattintva bármikor elolvashatja ezt az ismertetőt</p>

<p>A menüben található <span class="kiemelt">Munkatárs</span> gombra kattintva beléphet az alkalmazásaba. A belépést követően a felhasználói felület fogadja ahol a <span class="kiemelt">QR kód beolvasása</span> segítségével be illetve kiléphet a kapun.</p>

<p>Amennyiben belépett az Ön munkahelyi státusza <span class="kiemelt">Belépve</span> lesz és munkaideje elindult.</p>
<p>Amennyiben kilépett az Ön munkahelyi státusza <span class="kiemelt">Kilépve</span> lesz és munkaideje megállt.</p>
<p>Amennyiben Homeoffice-t választja az Ön munkahelyi státusza <span class="kiemelt">Homeoffice</span> lesz és munkaideje elindult.</p>
<p>Amennyiben Szabadságot vagy a Betegszabadságot választja az Ön munkahelyi státusza <span class="kiemelt">Szabadságon / Betegszabadságon</span> lesz az adott napra.</p>