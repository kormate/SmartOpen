-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Gép: 127.0.0.1
-- Létrehozás ideje: 2024. Máj 06. 10:50
-- Kiszolgáló verziója: 10.4.32-MariaDB
-- PHP verzió: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Adatbázis: `smartopen`
--

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `felhasznalok`
--

CREATE TABLE `felhasznalok` (
  `fname` varchar(100) NOT NULL,
  `fmail` varchar(100) NOT NULL DEFAULT 'a@v.hu',
  `fpw` varchar(100) NOT NULL,
  `fsalt` varchar(16) NOT NULL,
  `fmunkakor` text NOT NULL DEFAULT 'munkatars',
  `fstatusz` text NOT NULL DEFAULT 'kilepve'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- A tábla adatainak kiíratása `felhasznalok`
--

INSERT INTO `felhasznalok` (`fname`, `fmail`, `fpw`, `fsalt`, `fmunkakor`, `fstatusz`) VALUES
('Kiss Péter', 'admin@freemail.com', 'R/bSOOkTqiO0A2fBUzCYMo3misyc7bxnQhnLi54Q4trbKtnjp896DNKDdzZbiPIgsGeLDFebmI8k1u/2k3cdF0', 'vnnI9cOtJNogs6HM', 'munkatars', 'kilepve'),
('SZABO Gyula', 'admin@gmail.com', 'R/bSOOkTqiO0A2fBUzCYMo3misyc7bxnQhnLi54Q4trbKtnjp896DNKDdzZbiPIgsGeLDFebmI8k1u/2k3cdF0', 'vnnI9cOtJNogs6HM', 'munkatars', 'kilepve');

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `nap`
--

CREATE TABLE `nap` (
  `napid` int(11) NOT NULL,
  `fmail` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `qrkod`
--

CREATE TABLE `qrkod` (
  `qrid` int(11) NOT NULL,
  `qrszam` int(11) NOT NULL,
  `fmail` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- A tábla adatainak kiíratása `qrkod`
--

INSERT INTO `qrkod` (`qrid`, `qrszam`, `fmail`) VALUES
(1, 999999, '');

--
-- Indexek a kiírt táblákhoz
--

--
-- A tábla indexei `felhasznalok`
--
ALTER TABLE `felhasznalok`
  ADD PRIMARY KEY (`fmail`);

--
-- A tábla indexei `nap`
--
ALTER TABLE `nap`
  ADD PRIMARY KEY (`napid`),
  ADD KEY `fk_fmail` (`fmail`);

--
-- A tábla indexei `qrkod`
--
ALTER TABLE `qrkod`
  ADD PRIMARY KEY (`qrid`);

--
-- A kiírt táblák AUTO_INCREMENT értéke
--

--
-- AUTO_INCREMENT a táblához `nap`
--
ALTER TABLE `nap`
  MODIFY `napid` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT a táblához `qrkod`
--
ALTER TABLE `qrkod`
  MODIFY `qrid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Megkötések a kiírt táblákhoz
--

--
-- Megkötések a táblához `nap`
--
ALTER TABLE `nap`
  ADD CONSTRAINT `fk_fmail` FOREIGN KEY (`fmail`) REFERENCES `felhasznalok` (`fmail`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
